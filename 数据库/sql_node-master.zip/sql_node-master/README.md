# sql_node
sql学习笔记。
